package com.rest.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rest.entity.EmployeeEntity;
import com.rest.exceptions.EmployeesNotFoundException;
import com.rest.exceptions.NoSuchEmployeeException;
import com.rest.model.Employee;
import com.rest.repository.EmployeeRepository;

@Service
@Transactional
public class EmployeeService {
	@Autowired
	EmployeeRepository employeeRepository;
	
	
	public String insertEmployee(Employee employee) {
		EmployeeEntity entity =  new EmployeeEntity();
		entity.setCity(employee.getCity());
		entity.setEmpName(employee.getEmpName());
		entity.setSalary(employee.getSalary());
		employeeRepository.saveAndFlush(entity);
		return "Employee with employoee id "+entity.getEmpId() + " added successfully";
    }
	public String removeEmployee(int empId) throws NoSuchEmployeeException{
		Optional<EmployeeEntity> opt=employeeRepository.findById(empId);
		if(opt.isPresent())
		 {
			EmployeeEntity emp=opt.get();
			employeeRepository.delete(emp);
		 } 
		else {
			throw new NoSuchEmployeeException("Employee with " + empId + " does not exist");
		}
		return "Employee details deleted successfully";
	}
	
	public Employee findEmployee(int empId) throws NoSuchEmployeeException{
		Optional<EmployeeEntity> opt=employeeRepository.findById(empId);
		if(opt.isPresent()) {
			EmployeeEntity entity=opt.get();
			Employee emp = new Employee();
			emp.setCity(entity.getCity());
			emp.setEmpId(entity.getEmpId());
			emp.setEmpName(entity.getEmpName());
			emp.setSalary(entity.getSalary());
			return emp;
		}
		else {
			throw new NoSuchEmployeeException("Employee with " + empId + " does not exist");
		}
	}
	
	public List<Employee> getEmployoees() throws EmployeesNotFoundException{
		List<EmployeeEntity> entityList= employeeRepository.findAll();
		if(entityList.isEmpty() || entityList.size()==0) {
			throw new EmployeesNotFoundException("Employee details does not exist");
		}
		List<Employee>list = new ArrayList();
		for (EmployeeEntity entity : entityList) {
			Employee emp = new Employee();
			emp.setCity(entity.getCity());
			emp.setEmpId(entity.getEmpId());
			emp.setEmpName(entity.getEmpName());
			emp.setSalary(entity.getSalary());
			list.add(emp);
		}
		return list;
		
	}
	public String updateEmployee(Integer empId,Employee emp) throws NoSuchEmployeeException{
		Optional<EmployeeEntity> opt=employeeRepository.findById(empId);
		if(opt.isPresent())
		 {
			EmployeeEntity entity=opt.get();
			entity.setCity(emp.getCity());
			entity.setEmpName(emp.getEmpName());
			entity.setSalary(emp.getSalary());
			
		 } 
		else {
			throw new NoSuchEmployeeException("Employee with " + empId + " does not exist");
		}
		return "Employee details updated successfully";
	}


	/*
	 * public Employee findEmployeeByCity(String city){ Employee
	 * e=employeeRepository.findByCity(city); if(e!=null) return e; return null; }
	 */

}
